from fastapi import APIRouter
from agents.segmentation_agent import get_segment
from agents.risk_agent import get_risk_score
from agents.pricing_agent import get_recommended_price
from agents.recommendation_agent import get_recommendations
from agents.fraud_agent import detect_fraud
from agents.compliance_agent import check_compliance
import mysql.connector
from agents.llm_advisor_agent import ask_llm_advisor
from pydantic import BaseModel


DB_CONFIG = {
    "host": "localhost", "port": 3307,
    "user": "root", "password": "",
    "database": "ai_business_advisor"
}

class ChatRequest(BaseModel):
    question: str
router = APIRouter()


def get_client_age(client_id: int):
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    cursor.execute("SELECT age FROM clients WHERE client_id = %s", (client_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    return row[0] if row else None


@router.get("/analyse/{client_id}")
def analyse_client(client_id: int):
    segmentation_result = get_segment(client_id)
    risk_result = get_risk_score(client_id)
    pricing_result = get_recommended_price(client_id)
    recommendation_result = get_recommendations(client_id)
    fraud_result = detect_fraud(client_id)

    age = get_client_age(client_id)
    compliance_result = check_compliance(
        client_id=client_id,
        age=age,
        prime_recommandee=pricing_result.get("prime_recommandee", 0),
        prime_actuelle=pricing_result.get("prime_actuelle"),
        fraude_suspecte=fraud_result.get("fraude_suspecte", False)
    )

    return {
        "client_id": client_id,
        "segmentation": segmentation_result,
        "risque": risk_result,
        "pricing": pricing_result,
        "recommandations": recommendation_result,
        "fraude": fraud_result,
        "compliance": compliance_result
    }

@router.post("/chat/{client_id}")
def chat_with_advisor(client_id: int, request: ChatRequest):
    return ask_llm_advisor(client_id, request.question)