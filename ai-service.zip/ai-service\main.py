from fastapi import FastAPI
from agents.orchestrator import router as orchestrator_router

app = FastAPI(title="AI Business Advisor - Agents Service")

app.include_router(orchestrator_router)

@app.get("/")
def root():
    return {"status": "AI Service is running", "agents": 10}