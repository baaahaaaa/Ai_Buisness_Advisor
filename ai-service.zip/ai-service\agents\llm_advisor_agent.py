import os
import json
import logging
import sys
from datetime import datetime
from pathlib import Path

import mysql.connector
from dotenv import load_dotenv

from openai import (
    OpenAI,
    APIError,
    APITimeoutError,
    RateLimitError
)

# Add parent directory to path so imports work
sys.path.append(str(Path(__file__).parent.parent))

from agents.segmentation_agent import get_segment
from agents.risk_agent import get_risk_score
from agents.pricing_agent import get_recommended_price
from agents.recommendation_agent import get_recommendations
from agents.fraud_agent import detect_fraud
from agents.compliance_agent import check_compliance

load_dotenv()

API_KEY = os.getenv("XAI_API_KEY")
BASE_URL = os.getenv("XAI_BASE_URL", "https://api.x.ai/v1")
MODEL = os.getenv("MODEL", "grok-4")

client_openai = OpenAI(api_key=API_KEY, base_url=BASE_URL) if API_KEY else None

DB_CONFIG = {
    "host": "localhost",
    "port": 3307,
    "user": "root",
    "password": "",
    "database": "ai_business_advisor"
}

logging.basicConfig(
    filename="advisor.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)

conversation_memory = []

def add_to_memory(question, answer):
    conversation_memory.append({
        "question": question,
        "answer": answer,
        "date": datetime.now().isoformat()
    })
    if len(conversation_memory) > 10:
        conversation_memory.pop(0)

def check_api():
    if client_openai is None:
        raise Exception("XAI_API_KEY absente.")

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

def get_client(client_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM clients WHERE client_id=%s", (client_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    return row

# === SYSTEM PROMPT (added - was missing) ===
SYSTEM_PROMPT = """Tu es un conseiller expert en assurance automobile pour un directeur d'agence.
Tu analyses le contexte client fourni et donnes des réponses claires, stratégiques et actionnables en français."""

def build_context(client_id):
    client = get_client(client_id)
    if client is None:
        return None

    segmentation = get_segment(client_id)
    risk = get_risk_score(client_id)
    pricing = get_recommended_price(client_id)
    recommendation = get_recommendations(client_id)
    fraud = detect_fraud(client_id)
    compliance = check_compliance(
        client_id=client_id,
        age=client["age"],
        prime_actuelle=pricing["prime_actuelle"],
        prime_recommandee=pricing["prime_recommandee"],
        fraude_suspecte=fraud["fraude_suspecte"]
    )

    return {
        "client": client,
        "segmentation": segmentation,
        "risk": risk,
        "pricing": pricing,
        "recommendation": recommendation,
        "fraud": fraud,
        "compliance": compliance
    }

def build_prompt_context(context):
    # ... (your original function - kept as is)
    client = context["client"]
    # ... rest of your function unchanged
    return f"""
================ CLIENT ================
Nom : {client["prenom"]} {client["nom"]}
Age : {client["age"]}
Ville : {client["ville"]}

================ SEGMENTATION ================
Segment : {context["segmentation"]["segment_predit"]}
Description : {context["segmentation"].get("description","Non disponible")}

================ RISQUE ================
Score : {context["risk"]["score_risque"]}/100

================ PRICING ================
Prime actuelle : {context["pricing"]["prime_actuelle"]} DT
Prime recommandée : {context["pricing"]["prime_recommandee"]} DT

================ RECOMMANDATIONS ================
{", ".join(context["recommendation"]["recommandations"])}

================ FRAUDE ================
Fraude suspectée : {"Oui" if context["fraud"]["fraude_suspecte"] else "Non"}

================ CONFORMITE ================
Statut : {context["compliance"]["statut_conformite"]}
"""

def build_history():
    if not conversation_memory:
        return ""
    return "\n\n".join(
        f"Question :\n{item['question']}\nRéponse :\n{item['answer']}"
        for item in conversation_memory
    )

def ask_llm_advisor(client_id: int, question: str):
    try:
        check_api()
    except Exception as e:
        return {"success": False, "error": str(e)}

    context = build_context(client_id)
    if context is None:
        return {"success": False, "error": "Client introuvable"}

    context_text = build_prompt_context(context)
    history = build_history()

    user_prompt = f"""
Historique de conversation :
{history}

========================================
Contexte Client :
{context_text}
========================================
Question du directeur :
{question}
"""

    try:
        response = client_openai.chat.completions.create(
            model=MODEL,
            temperature=0.2,
            max_tokens=1000,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ]
        )
        answer = response.choices[0].message.content

        add_to_memory(question, answer)
        logging.info(f"Client={client_id} | Question={question}")

        return {
            "success": True,
            "client_id": client_id,
            "question": question,
            "answer": answer,
            "context": context
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    response = ask_llm_advisor(
        client_id=1,
        question="Analyse ce client et donne-moi une stratégie commerciale."
    )
    print(json.dumps(response, indent=4, ensure_ascii=False))